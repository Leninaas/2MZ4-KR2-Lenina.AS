
a = int(input("Введите int a: "))
b = int(input("Введите int b: "))
print ("Результат умножения: ", a*b)
