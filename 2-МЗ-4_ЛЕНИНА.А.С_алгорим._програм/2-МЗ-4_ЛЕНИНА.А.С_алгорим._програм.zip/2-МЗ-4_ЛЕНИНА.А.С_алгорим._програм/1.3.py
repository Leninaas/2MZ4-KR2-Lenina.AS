
a = int(input("Введите число abcd: "))
print("Сумма ab + cd равна: ", (a // 100) + (a % 100))
