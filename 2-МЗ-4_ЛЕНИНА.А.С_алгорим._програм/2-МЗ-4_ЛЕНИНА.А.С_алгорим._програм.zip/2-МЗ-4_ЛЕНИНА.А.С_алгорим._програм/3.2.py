
a = input("Введите натуральное число: ")
b = 0
for i in a:
    if int(i) > b:
        b =  int (i)
else:
    print(f"Наибольшая цифра в числе: {b}")
