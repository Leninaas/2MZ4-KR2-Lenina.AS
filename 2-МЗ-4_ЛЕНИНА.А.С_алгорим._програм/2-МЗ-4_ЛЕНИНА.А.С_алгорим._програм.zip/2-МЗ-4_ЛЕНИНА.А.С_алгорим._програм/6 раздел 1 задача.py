

spisok = [1,2,3,4,6]

b = int(input("Введите число: "))
if b in spisok:
    print("Супер, Вы угадали число!")
else: print("Нет такого числа!")
