

a = {"Декабрь": 35, "Январь": 39, "Февраль": 35, "Март": 27, "Июль": 78}

print(sorted(a.items(), key = lambda item: item[1]))
